package org.flexdock.test;
/*
 * Created on Mar 12, 2005
 */

/**
 * @author Christopher Butler
 */
public class Test {
	// placeholder class for CVS
}
