/**
 * Top level package for the information broker.     
 *
 * @since 1.0
 */
package net.xeoh.plugins.informationbroker;