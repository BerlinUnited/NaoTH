/**
 * Top level package for core options.     
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.options;