/**
 * Options to <code>publish()</code>.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.informationbroker.options.publish;