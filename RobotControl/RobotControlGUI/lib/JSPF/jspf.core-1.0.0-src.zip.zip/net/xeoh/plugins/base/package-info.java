/**
 * Contains the core plugin manager classes.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base;