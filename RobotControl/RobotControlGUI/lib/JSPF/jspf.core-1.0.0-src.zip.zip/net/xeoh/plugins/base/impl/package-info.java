/**
 * The {@link net.xeoh.plugins.base.impl.PluginManagerFactory} is the framework's entry point and the only class of 
 * relevance within this package, start exploring here.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.impl;