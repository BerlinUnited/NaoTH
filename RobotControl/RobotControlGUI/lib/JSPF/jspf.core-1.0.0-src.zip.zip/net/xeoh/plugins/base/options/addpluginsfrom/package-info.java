/**
 * Options to <code>addPluginsFrom()</code>.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.options.addpluginsfrom;