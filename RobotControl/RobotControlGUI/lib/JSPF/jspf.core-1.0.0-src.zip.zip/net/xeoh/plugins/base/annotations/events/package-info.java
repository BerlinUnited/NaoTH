/**
 * Annoations related to plugin events.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.annotations.events;