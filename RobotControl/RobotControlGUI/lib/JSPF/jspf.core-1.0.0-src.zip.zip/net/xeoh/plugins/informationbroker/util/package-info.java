/**
 * Utils for various {@link net.xeoh.plugins.informationbroker.InformationBroker} classes and objects.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.informationbroker.util;