/**
 * Options to <code>subscribe()</code>.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.informationbroker.options.subscribe;