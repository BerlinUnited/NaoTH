/**
 * Utilities for URIs.     
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.util.uri;