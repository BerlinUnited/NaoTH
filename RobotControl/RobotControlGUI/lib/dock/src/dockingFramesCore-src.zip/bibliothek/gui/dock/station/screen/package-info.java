/**
 * Elements that are related to the {@link bibliothek.gui.dock.ScreenDockStation}.
 */
package bibliothek.gui.dock.station.screen;