/**
 * Elements which are needed by the {@link bibliothek.gui.dock.SplitDockStation},
 * and which are needed to interact with the station.
 */
package bibliothek.gui.dock.station.split;