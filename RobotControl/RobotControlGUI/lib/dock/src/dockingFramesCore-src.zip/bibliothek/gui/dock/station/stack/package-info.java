/**
 * Elements which are related to the {@link bibliothek.gui.dock.StackDockStation}.
 */
package bibliothek.gui.dock.station.stack;