/**
 * Contains an abstract implementation of {@link bibliothek.gui.dock.station.stack.CombinedMenu}
 * including helper classes.
 */
package bibliothek.gui.dock.station.stack.menu;
