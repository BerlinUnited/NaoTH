/**
 * Classes and interfaces that are needed by the {@link bibliothek.gui.dock.station.DockableDisplayer}.
 */
package bibliothek.gui.dock.displayer;