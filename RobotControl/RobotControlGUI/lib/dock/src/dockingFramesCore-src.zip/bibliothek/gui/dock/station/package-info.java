/**
 * Elements needed by various implementations of the 
 * {@link bibliothek.gui.DockStation} interface.
 */
package bibliothek.gui.dock.station;