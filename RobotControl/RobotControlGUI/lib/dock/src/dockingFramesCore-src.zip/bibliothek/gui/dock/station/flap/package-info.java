/**
 * Elements that are related to the {@link bibliothek.gui.dock.FlapDockStation}.
 */
package bibliothek.gui.dock.station.flap;