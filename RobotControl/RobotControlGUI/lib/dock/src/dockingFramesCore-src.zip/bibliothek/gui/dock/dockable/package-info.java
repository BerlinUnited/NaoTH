/**
 * Some classes related to {@link bibliothek.gui.Dockable}. Most classes
 * in this package have no relationship to each other.
 */
package bibliothek.gui.dock.dockable;