/**
 * Classes and interfaces needed by the {@link bibliothek.gui.DockFrontend}
 */
package bibliothek.gui.dock.frontend;