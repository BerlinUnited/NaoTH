/**
 * The five basic classes implementing {@link bibliothek.gui.Dockable} and
 * {@link bibliothek.gui.DockStation} plus some supporting elements.
 */
package bibliothek.gui.dock;