/**
 * Elements dealing with the location of {@link bibliothek.gui.Dockable}s
 * on their {@link bibliothek.gui.DockStation} and allowing to store the
 * whole layout of a set of <code>Dockable</code>s and stations.
 */
package bibliothek.gui.dock.layout;