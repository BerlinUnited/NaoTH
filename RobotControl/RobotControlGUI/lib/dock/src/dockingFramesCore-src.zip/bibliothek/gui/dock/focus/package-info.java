/**
 * Contains classes that allow the user to switch between {@link java.awt.Component}s or
 * from one {@link bibliothek.gui.Dockable} to another using only the keyboard.
 */
package bibliothek.gui.dock.focus;
