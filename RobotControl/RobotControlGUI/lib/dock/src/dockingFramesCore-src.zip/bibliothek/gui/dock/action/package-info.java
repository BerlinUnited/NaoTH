/**
 * The components dealing with the logic of {@link bibliothek.gui.dock.action.DockAction}s.
 */
package bibliothek.gui.dock.action;