/**
 * Some simple utilty classes.
 */
package bibliothek.extension.gui.dock.util;