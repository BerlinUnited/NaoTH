/**
 * Contains the elements needed to paint a generic "tabbed pane".
 */
package bibliothek.extension.gui.dock.theme.eclipse.rex;