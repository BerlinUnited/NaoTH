/**
 * Implementations of various {@link bibliothek.extension.gui.dock.preference.Preference}s which 
 * are used in the default set of preferences.
 */
package bibliothek.extension.gui.dock.preference.preferences;