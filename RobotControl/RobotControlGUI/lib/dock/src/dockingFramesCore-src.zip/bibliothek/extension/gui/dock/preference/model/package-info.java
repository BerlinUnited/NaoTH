/**
 * A set of {@link bibliothek.extension.gui.dock.preference.PreferenceModel}s
 * that show properties of this framework. 
 */
package bibliothek.extension.gui.dock.preference.model;