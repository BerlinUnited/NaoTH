/**
 * Various components needed to paint and manage the tab which is visible
 * on a {@link bibliothek.extension.gui.dock.theme.eclipse.stack.EclipseTabPane}.
 */
package bibliothek.extension.gui.dock.theme.eclipse.stack.tab;