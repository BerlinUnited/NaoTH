/**
 * A set of small classes containing choices the user can make. Each choice 
 * represents one preference to set.
 */
package bibliothek.extension.gui.dock.preference.preferences.choice;
