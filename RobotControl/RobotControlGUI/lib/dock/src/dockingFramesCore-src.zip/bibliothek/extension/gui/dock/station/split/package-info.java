/**
 * Optional helper functions to keep the size of {@link bibliothek.gui.Dockable} 
 * even if the elements are moved around. The functionality of this package mostly
 * got obsolete when placeholders were introduced.
 */
package bibliothek.extension.gui.dock.station.split;