/**
 * Contains some {@link bibliothek.gui.DockTheme}s. <code>DockTheme</code>s can be exchanged
 * using {@link bibliothek.gui.DockController#setTheme(bibliothek.gui.DockTheme)}.
 */
package bibliothek.extension.gui.dock.theme;
