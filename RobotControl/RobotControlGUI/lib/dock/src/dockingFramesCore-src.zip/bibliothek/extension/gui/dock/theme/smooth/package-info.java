/**
 * Contains elements to paint a {@link bibliothek.gui.dock.title.DockTitle} which smoothly changes
 * its color.
 */
package bibliothek.extension.gui.dock.theme.smooth;