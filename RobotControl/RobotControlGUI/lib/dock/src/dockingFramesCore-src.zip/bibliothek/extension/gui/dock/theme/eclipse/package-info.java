/**
 * Various graphical and logical components needed when the 
 * {@link bibliothek.extension.gui.dock.theme.EclipseTheme}
 * is active.
 */
package bibliothek.extension.gui.dock.theme.eclipse;