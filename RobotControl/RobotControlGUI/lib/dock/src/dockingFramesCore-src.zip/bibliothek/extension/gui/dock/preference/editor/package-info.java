/**
 * A set of {@link bibliothek.extension.gui.dock.preference.PreferenceEditor}s
 * for types that are often used.
 */
package bibliothek.extension.gui.dock.preference.editor;