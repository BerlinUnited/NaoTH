/**
 * The {@link bibliothek.gui.dock.station.DockableDisplayer}s that are used
 * by the {@link bibliothek.extension.gui.dock.theme.EclipseTheme}.
 */
package bibliothek.extension.gui.dock.theme.eclipse.displayer;
