/**
 * An implementation of {@link bibliothek.gui.dock.station.stack.tab.TabPane} and
 * supporting classes for the {@link bibliothek.extension.gui.dock.theme.EclipseTheme}.
 */
package bibliothek.extension.gui.dock.theme.eclipse.stack;
