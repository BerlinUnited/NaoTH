package bibliothek.layouts;

public class Application {
    public static void main( String[] args ) {
        Core core = new Core();
        core.show( null );
        
//        CControl environment = core.getEnvironment().getEnvironmentControl();
//        environment.setTheme( ThemeMap.KEY_ECLIPSE_THEME );
//        Inspection.open( environment );
    }
}
