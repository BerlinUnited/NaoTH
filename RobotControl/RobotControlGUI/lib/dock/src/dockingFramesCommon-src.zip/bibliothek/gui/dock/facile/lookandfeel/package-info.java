/**
 * Generic helper classes for the {@link bibliothek.gui.dock.support.lookandfeel.LookAndFeelList}
 */
package bibliothek.gui.dock.facile.lookandfeel;