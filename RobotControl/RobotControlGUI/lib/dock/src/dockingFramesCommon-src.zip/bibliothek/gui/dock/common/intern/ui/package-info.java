/**
 * Base-classes intended for inheritance and small strategy-classes modifying the way <code>Core</code> works.
 */
package bibliothek.gui.dock.common.intern.ui;