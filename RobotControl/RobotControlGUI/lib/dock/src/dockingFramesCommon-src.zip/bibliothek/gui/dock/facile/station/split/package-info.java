/**
 * Support classes for {@link bibliothek.gui.dock.SplitDockStation}.
 */
package bibliothek.gui.dock.facile.station.split;