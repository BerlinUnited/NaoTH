/**
 * A set of more complex actions that can be directly used.
 */
package bibliothek.gui.dock.common.action.predefined;