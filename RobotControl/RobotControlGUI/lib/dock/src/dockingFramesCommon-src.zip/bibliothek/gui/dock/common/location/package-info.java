/**
 * Various implementations of {@link bibliothek.gui.dock.common.CLocation}. Clients can use these classes
 * either directly or go through the factory-methods provided by {@link bibliothek.gui.dock.common.CLocation} to create
 * new locations. 
 */
package bibliothek.gui.dock.common.location;