/**
 * Strategies helping a {@link bibliothek.gui.dock.facile.mode.LocationModeManager} to decide which modes are
 * available for a {@link bibliothek.gui.Dockable}. Clients can use the property
 * {@link bibliothek.gui.dock.facile.mode.LocationModeManager#MODE_ENABLEMENT} to replace the current strategy.
 */
package bibliothek.gui.dock.facile.mode.status;