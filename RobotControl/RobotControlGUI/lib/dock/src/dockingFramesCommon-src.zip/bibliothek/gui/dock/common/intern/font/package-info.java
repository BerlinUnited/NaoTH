/**
 * Various implementations of {@link bibliothek.gui.dock.util.font.FontBridge} to transfer
 * fonts stored in a {@link bibliothek.gui.dock.common.FontMap}. 
 */
package bibliothek.gui.dock.common.intern.font;