/**
 * A subclass of {@link bibliothek.gui.dock.facile.mode.LocationModeManager} that handles {@link bibliothek.gui.dock.common.CLocation}s,
 * {@link bibliothek.gui.dock.common.mode.ExtendedMode}s and is aware of {@link bibliothek.gui.dock.common.CControl}. Contains also various
 * subclasses of classes that are related with {@link bibliothek.gui.dock.facile.mode.LocationModeManager}.
 */
package bibliothek.gui.dock.common.mode;