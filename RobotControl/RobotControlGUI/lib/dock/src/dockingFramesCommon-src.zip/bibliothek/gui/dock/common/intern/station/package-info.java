/**
 * Contains the {@link bibliothek.gui.dock.common.intern.station.CommonStation}, various implementations of {@link bibliothek.gui.dock.common.intern.station.CommonStation} and supporting classes. 
 */
package bibliothek.gui.dock.common.intern.station;