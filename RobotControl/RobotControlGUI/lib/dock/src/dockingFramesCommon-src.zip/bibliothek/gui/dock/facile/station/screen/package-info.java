/**
 * Support classes for {@link bibliothek.gui.dock.ScreenDockStation}.
 */
package bibliothek.gui.dock.facile.station.screen;