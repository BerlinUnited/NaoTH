/**
 * Basic interfaces for a small framework that builds and manages {@link javax.swing.JMenu}s with changing content.
 */
package bibliothek.gui.dock.support.menu;